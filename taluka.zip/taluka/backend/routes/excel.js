const express     = require('express');
const router      = express.Router();
const mongoose    = require('mongoose');
const { protect, authorize } = require('../middleware/auth');
const upload      = require('../middleware/upload');
const XLSX        = require('xlsx');
const Revenue     = require('../models/Revenue');
const ExcelUpload = require('../models/ExcelUpload');
const Village     = require('../models/Village');

// ── helpers ───────────────────────────────────────────────────────────────────

function batchId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6).toUpperCase();
}

function normaliseRow(raw) {
  const out = {};
  for (const k of Object.keys(raw)) {
    const clean = k.trim().toLowerCase().replace(/\s+/g, '');
    out[clean] = typeof raw[k] === 'string' ? raw[k].trim() : raw[k];
  }
  return out;
}

function pick(row, ...keys) {
  for (const k of keys) {
    if (row[k] !== undefined && row[k] !== '') return row[k];
  }
  return '';
}

function parseRows(workbook) {
  const sheetName = workbook.SheetNames[0];
  const raw = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: '' });
  return raw.map(normaliseRow);
}

function buildPreview(rows) {
  return rows.slice(0, 10).map(row => ({
    type:        (pick(row, 'type', 'taxtype', 'tax_type') || '').toString().trim(),
    villageName: (pick(row, 'villagename', 'village_name', 'village', 'gram') || '').toString().trim().toLowerCase(),
    amount:      parseFloat(pick(row, 'amount', 'amt', 'totalamount') || 0),
    year:        parseInt(pick(row, 'year', 'yr') || new Date().getFullYear()),
    month:       parseInt(pick(row, 'month', 'mon', 'mm') || (new Date().getMonth() + 1)),
  }));
}

// ── Village validation helper ─────────────────────────────────────────────────
// Returns { valid: true } or { valid: false, invalidVillages: [...] }
async function validateVillages(allFiles) {
  // Collect all unique village names (lowercase) from all files combined
  const excelVillages = new Set();
  for (const fileData of allFiles) {
    for (const raw of (fileData.allRows || [])) {
      const row  = (typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
      const name = (pick(row, 'villagename', 'village_name', 'village', 'gram') || '')
        .toString().trim().toLowerCase();
      if (name) excelVillages.add(name);
    }
  }

  if (!excelVillages.size) return { valid: true, excelVillages: [] };

  // Fetch matching villages from DB (case-insensitive via nameLower field)
  const dbVillages = await Village.find({
    nameLower: { $in: [...excelVillages] },
    isActive: true
  }).lean();

  const dbVillageNames = new Set(dbVillages.map(v => v.nameLower));
  const invalidVillages = [...excelVillages].filter(v => !dbVillageNames.has(v));

  if (invalidVillages.length > 0) {
    return { valid: false, invalidVillages };
  }
  return { valid: true, excelVillages: [...excelVillages] };
}

// ── GET /api/excel/history ────────────────────────────────────────────────────

router.get('/history', protect, authorize('DataEntry', 'BDO', 'DeptHead'), async (req, res) => {
  try {
    const filter = {};
    if (req.user.role === 'DataEntry') {
      filter.userId = req.user._id;
    } else if (req.query.userId) {
      filter.userId = req.query.userId;
    }
    const history = await ExcelUpload.find(filter)
      .populate('userId', 'name email')
      .sort({ uploadedAt: -1 });
    res.json({ success: true, data: history, count: history.length });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── DELETE /api/excel/history/:id ─────────────────────────────────────────────

router.delete('/history/:id', protect, authorize('DataEntry', 'BDO'), async (req, res) => {
  try {
    const record = await ExcelUpload.findById(req.params.id);
    if (!record) return res.status(404).json({ success: false, message: 'Upload record not found' });
    if (req.user.role === 'DataEntry' && record.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }
    await ExcelUpload.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Upload record deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── POST /api/excel/preview ───────────────────────────────────────────────────
// Parse files + validate villages — return preview WITH validation result
// Does NOT save any data yet

router.post(
  '/preview',
  protect,
  authorize('BDO', 'DataEntry'),
  (req, res, next) => { req.uploadSubDir = 'excel'; next(); },
  upload.array('files', 20),
  async (req, res) => {
    try {
      if (!req.files || !req.files.length) {
        return res.status(400).json({ success: false, message: 'No files uploaded' });
      }

      const previews = req.files.map(file => {
        try {
          const workbook = XLSX.readFile(file.path);
          const rows     = parseRows(workbook);
          return {
            originalName: file.originalname,
            savedPath:    file.path,
            totalRows:    rows.length,
            columns:      rows.length ? Object.keys(rows[0]) : [],
            preview:      rows.slice(0, 10),
            allRows:      rows
          };
        } catch (e) {
          return {
            originalName: file.originalname,
            savedPath:    file.path,
            error:        'Failed to parse: ' + e.message,
            totalRows:    0, columns: [], preview: [], allRows: []
          };
        }
      });

      // ── Village validation at preview stage too (early warning) ──────────
      const validFiles = previews.filter(p => !p.error);
      const validation = await validateVillages(validFiles);

      // Tag each preview row as valid/invalid
      const previewsWithFlags = previews.map(p => {
        if (p.error || !validation.invalidVillages?.length) return p;
        // Mark rows that have an invalid village name
        const flagged = p.preview.map(row => {
          const vName = (pick(row, 'villagename', 'village_name', 'village', 'gram') || '')
            .toString().trim().toLowerCase();
          return { ...row, _invalidVillage: validation.invalidVillages.includes(vName) };
        });
        return { ...p, preview: flagged };
      });

      res.json({
        success:          true,
        message:          `Parsed ${req.files.length} file(s)`,
        fileCount:        req.files.length,
        previews:         previewsWithFlags,
        villageValidation: {
          valid:           validation.valid,
          invalidVillages: validation.invalidVillages || []
        }
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

// ── POST /api/excel/import-revenue ────────────────────────────────────────────
// VALIDATES villages first — blocks entire upload if any village is invalid

router.post('/import-revenue', protect, authorize('BDO', 'DataEntry'), async (req, res) => {
  try {
    const { files } = req.body;

    if (!files || !Array.isArray(files) || !files.length) {
      return res.status(400).json({ success: false, message: 'No file data provided' });
    }

    // ════════════════════════════════════════════════════════
    // STEP 1: Village validation — BLOCK if any village unknown
    // ════════════════════════════════════════════════════════
    const validation = await validateVillages(files);

    if (!validation.valid) {
      const names = validation.invalidVillages.map(v => `"${v}"`).join(', ');
      const msg   = validation.invalidVillages.length === 1
        ? `Village ${names} is not created by BDO. Please ask BDO to add it first.`
        : `These villages are not created by BDO: ${names}. Please ask BDO to add them first.`;

      return res.status(400).json({
        success:         false,
        message:         msg,
        invalidVillages: validation.invalidVillages,
        code:            'VILLAGE_NOT_FOUND'
      });
    }

    // ════════════════════════════════════════════════════════
    // STEP 2: Parse rows and insert (all villages are valid)
    // ════════════════════════════════════════════════════════
    const batch          = batchId();
    const now            = new Date();
    const inserted       = [];
    const errors         = [];
    const historyRecords = [];

    for (const fileData of files) {
      const { originalName, allRows, savedPath } = fileData;
      if (!allRows || !allRows.length) continue;

      const fileInserted = [];
      const fileErrors   = [];

      for (const raw of allRows) {
        const row = (typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};

        const villageName = (pick(row, 'villagename', 'village_name', 'village', 'gram') || '')
          .toString().trim().toLowerCase();
        const type        = (pick(row, 'type', 'taxtype', 'tax_type', 'revenuetype') || '')
          .toString().trim();
        const amount      = parseFloat(pick(row, 'amount', 'amt', 'totalamount', 'total') || 0);
        const year        = parseInt(pick(row, 'year', 'yr')        || now.getFullYear());
        const month       = parseInt(pick(row, 'month', 'mon', 'mm') || (now.getMonth() + 1));
        const date        = (pick(row, 'date', 'dt', 'day') || '').toString().trim();

        if (!villageName || !type || amount <= 0) {
          fileErrors.push({ row, reason: 'Missing villageName/type or amount ≤ 0' });
          errors.push({ file: originalName, row, reason: 'Missing villageName/type or amount ≤ 0' });
          continue;
        }

        const entry = { villageName, type, amount, dueAmount: 0, year, month, date, uploadedBy: req.user._id, uploadBatchId: batch };
        fileInserted.push(entry);
        inserted.push(entry);
      }

      historyRecords.push({
        userId:       req.user._id,
        fileName:     originalName,
        filePath:     savedPath || '',
        totalRows:    allRows.length,
        importedRows: fileInserted.length,
        skippedRows:  fileErrors.length,
        batchId:      batch,
        previewData:  buildPreview(allRows),
        uploadedAt:   now
      });
    }

    if (!inserted.length) {
      return res.status(400).json({
        success: false,
        message: 'No valid rows found. Required columns: type, villageName, amount, year, month.',
        errors
      });
    }

    const [revenueResult] = await Promise.all([
      Revenue.insertMany(inserted, { ordered: false }),
      ExcelUpload.insertMany(historyRecords, { ordered: false })
    ]);

    res.json({
      success: true,
      message: `Imported ${revenueResult.length} revenue entries across ${files.length} file(s)`,
      count:   revenueResult.length,
      batchId: batch,
      skipped: errors.length,
      errors:  errors.slice(0, 10)
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── KYC import (unchanged) ────────────────────────────────────────────────────
const KYC = require('../models/KYC');

router.post('/import-kyc', protect, authorize('BDO', 'DataEntry'), async (req, res) => {
  try {
    const { data, villageId } = req.body;
    if (!data || !Array.isArray(data)) {
      return res.status(400).json({ success: false, message: 'No data provided' });
    }
    const kycs = data.map(row => ({
      name:        row.name    || row.Name    || '',
      aadhaar:     String(row.aadhaar || '000000000000'),
      address:     row.address || '',
      mobile:      String(row.mobile  || ''),
      gender:      row.gender  || 'Male',
      mode:        'offline', status: 'pending',
      submittedBy: req.user._id,
      villageId:   villageId || null
    })).filter(k => k.name);
    const result = await KYC.insertMany(kycs, { ordered: false });
    res.json({ success: true, message: `Imported ${result.length} KYC records`, count: result.length });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
